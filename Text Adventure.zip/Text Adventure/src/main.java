import java.util.Scanner;
import java.util.Random;
public class main {

    public static void main(String[] args) {

        Scanner playerInput;
        playerInput = new Scanner (System.in);
        System.out.println("What is your character's name?");
        String playerName = playerInput.nextLine();
        System.out.println("ok " + playerName + ", do you want to start your adventure?");
        System.out.println("1 - Yes");
        System.out.println("2 - No");
        int gameStart = playerInput.nextInt();

        // ascii art welcome screen
        if (gameStart == 1) {
            System.out.println("__          __  _                          ");
            System.out.println("\\ \\        / / | |                         ");
            System.out.println(" \\ \\  /\\  / /__| | ___ ___  _ __ ___   ___ ");
            System.out.println("  \\ \\/  \\/ / _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\");
            System.out.println("   \\  /\\  /  __/ | (_| (_) | | | | | |  __/");
            System.out.println("    \\/  \\/ \\___|_|\\___\\___/|_| |_| |_|\\___|");

            System.out.println("do you want to enter the cave to the right of you, or the dark forest to the left?");
            System.out.println("1 - Cave");
            System.out.println("2 - Forest");
            int rl = playerInput.nextInt();

            if (rl == 2) {

                System.out.println("While approaching the forest, you hear loud grunting.");
                System.out.println("On further inspection, you see a faint outline of what looks like a dragon.");
                System.out.println("Because of this, you decide to run home, go to sleep, and forget that any of this ever happened.");
            }

            if (rl == 1) {
                System.out.println("you walk into the cave, and realise that you have no light source. You: ");
                System.out.println("1 - Make a fire");
                System.out.println("2 - go home and watch tv");
                int fire1 = playerInput.nextInt();

                if (fire1 == 1) {
                    int fireTime;
                    Random randomGenerator = new Random();
                    fireTime = randomGenerator.nextInt(5)+2;
                    System.out.println("after " + fireTime + " hours, you created a fire.");
                    System.out.println("what do you want to do now?");
                    System.out.println("1 - Go to sleep");
                    System.out.println("2 - Venture into the cave");

                    int lightNow;
                    lightNow = playerInput.nextInt();

                    if (lightNow == 1) {
                        System.out.println("You go to sleep, only to never wake up, as you were the perfect snack for a nearby dragon...");
                    }

                    if (lightNow == 2) {
                        System.out.println("You slowly walk into the cave, to find a huge dragon.");
                        System.out.println(" ");
                        System.out.println("1 - Run");
                        System.out.println("2 - Fight the dragon");

                        int fiteRun;
                        fiteRun = playerInput.nextInt();

                        if (fiteRun == 2) {
                            System.out.println("Pick a number 0-1");
                            int randomNumber;
                            randomNumber = playerInput.nextInt();

                            int numberValue;
                            numberValue = randomGenerator.nextInt(1);

                            if (randomNumber != numberValue) {

                                System.out.println("GAME OVER");
                                System.out.println("You were unable to kill the dragon.");

                            }

                            while (randomNumber == numberValue) {
                                System.out.println("you have defeated the dragon!!!!!!");
                            }


                        }


                        if (fiteRun == 1) {
                            int randomGen1;
                            randomGen1 = randomGenerator.nextInt(1);

                            if (randomGen1 == 1) {
                                System.out.println("You have successfully escaped the cave, and ran home.");
                            } else {
                                System.out.println("GAME OVER");
                                System.out.println("You were fast, but the Dragon was faster!");

                            }
                        }
                    }


                } else {
                    System.out.println("You go home to watch the entire 3rd season of Stranger Things in one night.");
                }




            }

        }else {

            System.out.println("then why are you even here?");
        }




    }

}